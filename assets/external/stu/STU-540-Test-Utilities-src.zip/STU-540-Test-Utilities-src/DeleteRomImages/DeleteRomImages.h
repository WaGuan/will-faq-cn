#pragma once

#include "../DemoCommon.hpp"

#define IDD_Dialog 1
#define IDC_Dialog_Action 0x8001

#define IDS_DeleteRomImages_Done    0x12
