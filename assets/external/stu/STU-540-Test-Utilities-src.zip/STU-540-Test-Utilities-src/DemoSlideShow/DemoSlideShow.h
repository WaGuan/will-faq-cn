#pragma once

#include "../DemoCommon.hpp"

#define IDD_Dialog 1
#define IDC_DemoSlideShow_Upload         0x8001
#define IDC_DemoSlideShow_Start          0x8002
#define IDC_DemoSlideShow_Stop           0x8003



