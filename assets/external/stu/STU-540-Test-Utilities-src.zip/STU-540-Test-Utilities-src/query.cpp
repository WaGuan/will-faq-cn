/// @file      query.cpp
/// @copyright Copyright (c) 2011 Wacom Company Limited
/// @author    mholden
/// @date      2012-03-22
/// @brief     simple test harness

/// TODO: Add comments!

#include <WacomGSS/STU/getUsbDevices.hpp>
#include <WacomGSS/STU/UsbInterface.hpp>
#include <WacomGSS/STU/SerialInterface.hpp>
#include <WacomGSS/STU/ProtocolHelper.hpp>

#include <locale>
#include <codecvt>

#include <iostream>
#include <sstream>
#include <iomanip>



template<typename InputIterator> struct ArrHex
{
  InputIterator begin, end;
  ArrHex(InputIterator const & b, InputIterator const & e) : begin(b), end(e) {}
};
template<typename InputIterator> std::ostream & operator << (std::ostream & o, ArrHex<InputIterator> const & arr)
{
  o << std::hex << std::setfill('0');
  for (auto i = arr.begin; i != arr.end; ++i)
    o << std::setw(2) << (unsigned)*i;
  o << std::dec << std::setfill(' ');
  return o;
}
template<typename InputIterator> auto arrhex(InputIterator const & b, InputIterator const & e) -> ArrHex<InputIterator>               { return ArrHex<InputIterator>(b, e); }
template<typename Container>     auto arrhex(Container const & c)                              -> decltype(arrhex(c.begin(),c.end())) { return arrhex(c.begin(), c.end()); }



using namespace WacomGSS::STU::ProtocolHelper::ostream_operators;



std::ostream & operator << (std::ostream & o, WacomGSS::STU::Protocol::EncodingFlag eF)
{
  std::uint8_t encodingFlag(eF);
  bool flag = false;

#define WacomGSS_EncodingFlag_Entry(Name) \
  if (encodingFlag & WacomGSS::STU::Protocol::EncodingFlag_##Name)   \
  {                                         \
    flag = true;                            \
    o << #Name;                             \
    encodingFlag &= ~WacomGSS::STU::Protocol::EncodingFlag_##Name; \
  }

  WacomGSS_EncodingFlag_Entry(24bit)
  WacomGSS_EncodingFlag_Entry(16bit)
  WacomGSS_EncodingFlag_Entry(1bit)
  WacomGSS_EncodingFlag_Entry(Zlib)
  if (encodingFlag || !flag)
  {
    if (flag)
      o << '|';
    o << "0x" << std::hex << std::setfill('0') << std::setw(2) << (unsigned)encodingFlag;
  }
  return o;
}



void romImageHash_common(WacomGSS::STU::Protocol & protocol, WacomGSS::STU::Protocol::OperationModeType operationModeType, bool pushed, uint8_t imageNumber, std::stringstream & o) 
{
  using namespace std;
  using namespace WacomGSS::STU;

  cout << setw(39) << left << o.str() << "   = ";

//  ProtocolHelper::waitForStatusToSend(protocol, Protocol::ReportId_RomImageHash, ProtocolHelper::OpDirectionSet);

  ProtocolHelper::waitForStatus(protocol, Protocol::StatusCode_Ready);
  protocol.setRomImageHash(operationModeType, pushed, imageNumber);

  ProtocolHelper::waitForStatus(protocol, Protocol::StatusCode_Ready);
  Protocol::RomImageHash hash = protocol.getRomImageHash();

  if (hash.result == 0)
  {
    cout << arrhex(hash.hash);
  }
  else
  {
    cout << "not stored";
  }
  cout << endl;
}



void romImageHash(WacomGSS::STU::Protocol & protocol, WacomGSS::STU::Protocol::OperationModeType operationModeType, uint8_t imageNumber) 
{
  using namespace std;

  stringstream o;
  o << "RomImageHash[" << operationModeType << "," << (unsigned)imageNumber << "]";

  romImageHash_common(protocol, operationModeType, false, imageNumber, o);
}



void romImageHash(WacomGSS::STU::Protocol & protocol, WacomGSS::STU::Protocol::OperationModeType operationModeType, bool pushed, uint8_t imageNumber) 
{
  using namespace std;

  stringstream o;
  o << "RomImageHash[" << operationModeType << "," << (unsigned)imageNumber <<"," << (pushed?"pushed":"normal") << "]";

  romImageHash_common(protocol, operationModeType, pushed, imageNumber, o);
}



void query(WacomGSS::STU::Protocol protocol)
{
  using namespace std;
  using namespace WacomGSS::STU;


  Protocol::Status status = protocol.getStatus();
  cout
    << "Status.statusCode                         = " << status.statusCode << endl
    << "Status.lastResultCode                     = " << status.lastResultCode << endl
    << "Status.statusWord                         = " << hex << setw(2) << setfill('0') << status.statusWord << dec << setfill(' ') << endl
  ;

  bool force = false;
  std::array<uint16_t,256> reportCountLengths = { 0 };
  bool rcl = protocol->getReportCountLengths(reportCountLengths);
  if (!rcl)
  {
#ifdef WacomGSS_WIN32
    cout << "unable to get reportCountLengths" << endl;
    if (!force)
      return;
#else
    cout << "Warning: unable to get reportCountLengths" << endl;
    force = true;
#endif
  }

  if (force || reportCountLengths[Protocol::ReportId_HidInformation])
  {
    Protocol::HidInformation hidInformation = protocol.getHidInformation();
    cout 
      << "HidInformation                            = " << hex << setfill('0') << setw(4) << hidInformation.idVendor << ':' << setw(4) << hidInformation.idProduct << ':' << setw(4) << hidInformation.bcdDevice << dec << endl;
    // Win32  = ERROR_GEN_FAILURE
    // libusb = ::LIBUSB_ERROR_PIPE
    // serial = timeout_error
  }
  else
  {
    cout << "HidInformation - not supported" << endl;
  }

  Protocol::Information inf = protocol.getInformation();
  cout 
    << "Information.modelName                     = " << inf.modelNameNullTerminated        << endl
    << "Information.firmwareMajorVersion          = " << hex << setw(2) << setfill('0') << (unsigned)inf.firmwareMajorVersion << dec << setfill(' ') << endl
    << "Information.firmwareMinorVersion          = " << hex << setw(2) << setfill('0') << (unsigned)inf.firmwareMinorVersion << dec << setfill(' ') << endl
    << "Information.secureIc                      = " << (unsigned)inf.secureIc             << endl
    << "Information.secureVersion                 = " << hex << (unsigned)inf.secureIcVersion[0] << '.'
                                                             << (unsigned)inf.secureIcVersion[1] << '.'
                                                             << (unsigned)inf.secureIcVersion[2] << '.'
                                                             << (unsigned)inf.secureIcVersion[3] <<
                                                         dec << endl
  ;

  Protocol::Capability caps = protocol.getCapability();
  cout
    << "Capability.tabletMaxX                     = " << caps.tabletMaxX              << endl
    << "Capability.tabletMaxY                     = " << caps.tabletMaxY              << endl
    << "Capability.tabletMaxPressure              = " << caps.tabletMaxPressure       << endl
    << "Capability.screenWidth                    = " << caps.screenWidth             << endl
    << "Capability.screenHeight                   = " << caps.screenHeight            << endl
    << "Capability.maxReportRate                  = " << (unsigned)caps.maxReportRate << endl
    << "Capability.resolution                     = " << caps.resolution              << endl
    << "Capability.encodingFlag                   = " << Protocol::EncodingFlag(caps.encodingFlag) << endl
  ;

  uint32_t uid = protocol.getUid();
  cout 
    << "Uid                                       = " << "0x" << hex << setw(8) << setfill('0') << uid << dec << setfill(' ') << endl;

  if (force || reportCountLengths[Protocol::ReportId_Uid2])
  {
    Protocol::Uid2 uid2 = protocol.getUid2();
    cout 
      << "Uid2                                      = " << uid2.uid2NullTerminated << endl;
    // Win32  = ERROR_GEN_FAILURE
    // libusb = ::LIBUSB_ERROR_PIPE
    // serial = timeout_error
  }
  else
  {
    cout << "Uid2 - not supported" << endl;
  }


  if (force || reportCountLengths[Protocol::ReportId_Eserial])
  {
    Protocol::Eserial eSerial = protocol.getEserial();
    cout 
      << "Eserial                                   = " << eSerial.eSerialNullTerminated << endl;
    // Win32  = ERROR_GEN_FAILURE
    // libusb = ::LIBUSB_ERROR_PIPE
    // serial = timeout_error
  }
  else
  {
    cout << "Eserial - not supported" << endl;
  }


  if (force || reportCountLengths[Protocol::ReportId_DefaultMode])
  {
    uint8_t defaultMode = protocol.getDefaultMode();
    cout 
      << "DefaultMode                               = " << static_cast<Protocol::DefaultMode>(defaultMode) << endl;
  }
  else
  {
    cout << "DefaultMode - not supported" << endl;
  }

  if (force || reportCountLengths[Protocol::ReportId_RenderingMode])
  {
    uint8_t renderingMode = protocol.getRenderingMode();
    cout 
      << "RenderingMode                             = " << static_cast<Protocol::RenderingMode>(renderingMode) << endl;
  }
  else
  {
    cout << "RenderingMode - not supported" << endl;
  }


  if (force || reportCountLengths[Protocol::ReportId_ReportRate])
  {
    uint8_t reportRate = protocol.getReportRate();
    cout 
      << "ReportRate                                = " << (unsigned)reportRate << endl;
  }
  else
  {
    cout << "ReportRate - not supported" << endl;
  }


  if (force || reportCountLengths[Protocol::ReportId_HostPublicKey])
  {
    try
    {
      Protocol::PublicKey hostPublicKey = protocol.getHostPublicKey();
      cout << "HostPublicKey                             = " << arrhex(hostPublicKey) << endl;
    }
    catch (...)
    {
      cout << "HostPublicKey - reportCountLength says supported but call failed" << endl;
    }
  }
  else
  {
    cout << "HostPublicKey - not supported" << endl;
  }

  if (force || reportCountLengths[Protocol::ReportId_DevicePublicKey])
  {
    try
    {
      Protocol::PublicKey devicePublicKey = protocol.getDevicePublicKey();
      cout << "DevicePublicKey                           = " << arrhex(devicePublicKey) << endl;
      // Win32  = ERROR_GEN_FAILURE
      // libusb = ::LIBUSB_ERROR_PIPE
      // serial = timeout_error
    }
    catch (...)
    {
      cout << "DevicePublicKey - reportCountLength says supported but call failed" << endl;
    }

  }
  else
  {
    cout << "DevicePublicKey - not supported" << endl;
  }

  if (force || reportCountLengths[Protocol::ReportId_DHprime])
  {
    Protocol::DHprime dhPrime = protocol.getDHprime();
    cout 
      << "DHprime                                   = " << arrhex(dhPrime) << endl;
  }
  else
  {
    cout << "DHprime - not supported" << endl;
  }

  if (force || reportCountLengths[Protocol::ReportId_DHbase])
  {
    Protocol::DHbase dhBase = protocol.getDHbase();
    cout 
      << "DHbase                                    = " << arrhex(dhBase) << endl;
  }
  else
  {
    cout << "DHbase - not supported" << endl;
  }

  uint8_t inkingMode = protocol.getInkingMode();
  cout 
    << "InkingMode                                = " << static_cast<Protocol::InkingMode>(inkingMode) << endl;

  Protocol::InkThreshold inkThreshold = protocol.getInkThreshold();
  cout 
    << "InkThreshold.onPressureMark               = " << inkThreshold.onPressureMark << endl
    << "InkThreshold.offPressureMark              = " << inkThreshold.offPressureMark << endl
  ;

  if (force || reportCountLengths[Protocol::ReportId_HandwritingThicknessColor])
  {
    Protocol::HandwritingThicknessColor handwritingThicknessColor = protocol.getHandwritingThicknessColor();
    cout
      << "HandwritingThicknessColor.penColor        = " << hex << setw(4) << setfill('0') << handwritingThicknessColor.penColor << setfill(' ') << dec << endl
      << "HandwritingThicknessColor.penThickness    = " << (unsigned)handwritingThicknessColor.penThickness << endl
    ;
    // Win32 = ERROR_CRC
    // libusb = ::LIBUSB_ERROR_PIPE
    // serial = timeout_error
  }
  else
  {
    cout << "HandwritingThicknessColor - not supported" << endl;
  }

  if (force || reportCountLengths[Protocol::ReportId_BackgroundColor])
  {
    uint16_t backgroundColor = protocol.getBackgroundColor();
    cout 
      << "BackgroundColor                           = " << hex << setw(4) << setfill('0') << backgroundColor << setfill(' ') << dec << endl;
  }
  else
  {
    cout << "BackgroundColor - not supported" << endl;
  }

  if (force || reportCountLengths[Protocol::ReportId_HandwritingDisplayArea])
  {
    Protocol::Rectangle area = protocol.getHandwritingDisplayArea();
    cout 
      << "HandwritingDisplayArea.upperLeftXpixel    = " << area.upperLeftXpixel  << endl
      << "HandwritingDisplayArea.upperLeftYpixel    = " << area.upperLeftYpixel  << endl
      << "HandwritingDisplayArea.lowerRightXpixel   = " << area.lowerRightXpixel << endl
      << "HandwritingDisplayArea.lowerRightYpixel   = " << area.lowerRightYpixel << endl
    ;
  }
  else
  {
    cout << "HandwritingDisplayArea - not supported" << endl;
  }

  if (force || reportCountLengths[Protocol::ReportId_BacklightBrightness])
  {
    uint16_t backlightBrightness = protocol.getBacklightBrightness();
    cout 
      << "BacklightBrightness                       = " << backlightBrightness << endl;
  }
  else
  {
    // Win32 = ERROR_CRC
    // libusb = ::LIBUSB_ERROR_PIPE
    // serial = timeout_error
    cout << "BacklightBrightness - not supported" << endl;
  }


  if (force || reportCountLengths[Protocol::ReportId_ScreenContrast])
  {
    uint16_t screenContrast = protocol.getScreenContrast();
    cout 
      << "ScreenContrast                            = " << hex << setw(4) << setfill('0') << screenContrast << setfill(' ') << endl;
  }
  else
  {
    // Win32 = ERROR_CRC
    // libusb = ::LIBUSB_ERROR_PIPE
    // serial = timeout_error
    cout << "ScreenContrast - not supported" << endl;
  }

  if (force || reportCountLengths[Protocol::ReportId_HandwritingThicknessColor24])
  {
    Protocol::HandwritingThicknessColor24 handwritingThicknessColor24 = protocol.getHandwritingThicknessColor24();
    cout
      << "HandwritingThicknessColor24.penColor      = " << hex << setw(6) << setfill('0') << handwritingThicknessColor24.penColor << setfill(' ') << dec << endl
      << "HandwritingThicknessColor24.penThickness  = " << (unsigned)handwritingThicknessColor24.penThickness << endl
    ;
    // Win32 = ERROR_CRC
    // libusb = ::LIBUSB_ERROR_PIPE
    // serial = timeout_error
  }
  else
  {
    cout << "HandwritingThicknessColor24 - not supported" << endl;
  }

  if (force || reportCountLengths[Protocol::ReportId_BackgroundColor24])
  {
    uint32_t backgroundColor24 = protocol.getBackgroundColor24();
    cout 
      << "BackgroundColor24                         = " << hex << setw(6) << setfill('0') << backgroundColor24 << setfill(' ') << dec << endl;
  }
  else
  {
    cout << "BackgroundColor24 - not supported" << endl;
  }

  // BootScreen

  if (force || reportCountLengths[Protocol::ReportId_PenDataOptionMode])
  {
    uint8_t penDataOptionMode = protocol.getPenDataOptionMode();
    cout 
      << "PenDataOptionMode                         = " << static_cast<Protocol::PenDataOptionMode>(penDataOptionMode) << endl;
  }
  else
  {
    cout << "PenDataOptionMode - not supported" << endl;
  }


  if (force || reportCountLengths[Protocol::ReportId_OperationMode])
  {
    Protocol::OperationMode operationMode = protocol.getOperationMode();
    cout 
      << "OperationMode                             = " << static_cast<Protocol::OperationModeType>(operationMode.operationMode) << endl;
  }
  else
  {
    cout << "OperationMode - not supported" << endl;
  }

  if (force || reportCountLengths[Protocol::ReportId_RomImageHash])
  {
    for (uint8_t imageNumber = 1; imageNumber <= 3; ++imageNumber)
    { 
      romImageHash(protocol, Protocol::OperationModeType_PinPad, false, imageNumber);
      romImageHash(protocol, Protocol::OperationModeType_PinPad, true , imageNumber);
    }
    for (uint8_t imageNumber = 1; imageNumber <= 10; ++imageNumber)
    { 
      romImageHash(protocol, Protocol::OperationModeType_SlideShow, imageNumber);
    }
    for (uint8_t imageNumber = 1; imageNumber <= 3; ++imageNumber)
    { 
      romImageHash(protocol, Protocol::OperationModeType_KeyPad, false, imageNumber);
      romImageHash(protocol, Protocol::OperationModeType_KeyPad, true , imageNumber);
    }
    for (uint8_t imageNumber = 1; imageNumber <= 3; ++imageNumber)
    { 
      romImageHash(protocol, Protocol::OperationModeType_Signature, false, imageNumber);
      romImageHash(protocol, Protocol::OperationModeType_Signature, true , imageNumber);
    }
    for (uint8_t imageNumber = 1; imageNumber <= 6; ++imageNumber)
    { 
      romImageHash(protocol, Protocol::OperationModeType_MessageBox, imageNumber);
    }
  }
  else
  {
    cout << "RomImageHash - not supported" << endl;
  }


  if (force || reportCountLengths[Protocol::ReportId_ReportSizeCollection])
  {
    Protocol::ReportSizeCollection reportSizeCollection = protocol.getReportSizeCollection();
#if 0
    cout 
      << "ReportSizeCollection                      =";
    for (auto i : reportSizeCollection)
    {
      cout <<  " " << hex << setfill('0') << setw(2) << i << dec; 
    }
    cout << endl;
#else
    cout 
      << "ReportSizeCollection                      ="<<endl;
    for (unsigned int i = 0; i < 256; ++i)
    {
      stringstream s;
      s << static_cast<Protocol::ReportId>(i);
      if (s.str().size() > 3 || reportSizeCollection[i] != 0)
      {
        cout <<  "  " << setw(34) << static_cast<Protocol::ReportId>(i) << " "; 
        if (reportSizeCollection[i])
        {
          cout << (unsigned)reportSizeCollection[i]; 
        }
        else
        {
          cout << "-"; 
        }
        cout << endl;
      }
    }
#endif
  }
  else
  {
    cout << "ReportSizeCollection - not supported" << endl;
    
  }

}



void queryUsb()
{
  using namespace std;
  using namespace WacomGSS::STU;

  auto usbDevices = getUsbDevices();

  if (!usbDevices.empty()) 
  {
    for (auto const & usbDevice : usbDevices)
    {
      try
      {
        cout << "Device: " << hex << setfill('0') << setw(4) << usbDevice.idVendor << ':' << setw(4) << usbDevice.idProduct << ':' << setw(4) << usbDevice.bcdDevice << dec << endl;

        UsbInterface intf;
        auto ec = intf.connect(usbDevice, true);
        if (!ec)
        {
          query(intf);
          intf.disconnect();
        }
        else
        {
          cout << "Failed to connect:" << ec << endl;
        }
        cout << endl;
      }
      catch (system_error const & ex)
      {
        cout << "system error: " << ex.what() << " " << ex.code() << " " << ex.code().message() << endl;
      }
    }
  }
  else 
  {
    cout << "No USB devices found" << endl;
  }
}


void querySerial(char const * comPort, std::uint32_t baudRate)
{
#ifndef __MACH__
  using namespace std;
  using namespace WacomGSS::STU;
  try
  {
    wstring port;

#if defined(WacomGSS_WIN32)
    wstring_convert<codecvt_utf8_utf16<wchar_t, 0x10ffff, little_endian>,wchar_t> conv;
    auto comPort_s = conv.from_bytes(comPort);
#else
    auto comPort_s = comPort;
#endif
    cout << "connecting to " << comPort << "  " << baudRate << endl;
    
    SerialInterface intf;
    error_code ec = intf.connect(comPort_s, baudRate, true);
    if (!ec)
    {
      query(intf);
      intf.disconnect();
    }
    else
    {
      cout << "Failed to connect:" << ec << endl;
    }
    cout << endl;
  }
  catch (system_error const & ex)
  {
    cout << "system error: " << ex.what() << " " << ex.code() << " " << ex.code().message() << endl;
  }
#endif
}



int main(int, char * * argv)
{
  try
  {
    std::cout << "STU query sample" << std::endl << std::endl;

    if (!*++argv)
      queryUsb();
    else
    {
      char const * port = *argv;
      if (port)
      {
        char const * rate = *++argv;

        std::uint32_t baudRate;
        if (rate)
        {
          baudRate = std::strtoul(rate, nullptr, 0);
        }
        else
        {
          baudRate = WacomGSS::STU::SerialInterface::BaudRate_STU430;
        }
        querySerial(port, baudRate);
      }
      else
      {
        std::cout << "args: serialPort baudRate"  << std::endl;
        
      }
    }
  }
  catch (std::exception const & ex)
  {
    std::cout << "std::exception: " << ex.what() << std::endl;
  }

  return 0;
}
