#include <no_crt.hxx>
#include <ptr.h>

using namespace mph::no_crt;

PWSTR disp(PWSTR p, DWORD iDevNum, DISPLAY_DEVICE DisplayDevice, BOOL indent) {
  WCHAR StateFlags[256];
  StateFlags[0] = 0;
  BOOL one = false;
  if (DisplayDevice.StateFlags & DISPLAY_DEVICE_ATTACHED_TO_DESKTOP) {
    one = true;
    lstrcat(StateFlags, L"ATTACHED_TO_DESKTOP");
  }
  if (DisplayDevice.StateFlags & DISPLAY_DEVICE_MULTI_DRIVER) {
    if (one) lstrcat(StateFlags, L" "); one = true;
    lstrcat(StateFlags, L"MULTI_DRIVER");
  }
  if (DisplayDevice.StateFlags & DISPLAY_DEVICE_MIRRORING_DRIVER) {
    if (one) lstrcat(StateFlags, L" "); one = true;
    lstrcat(StateFlags, L"MIRRORING_DRIVER");
  }
  if (DisplayDevice.StateFlags & DISPLAY_DEVICE_REMOVABLE) {
    if (one) lstrcat(StateFlags, L" "); one = true;
    lstrcat(StateFlags, L"REMOVABLE");
  }
  if (DisplayDevice.StateFlags & DISPLAY_DEVICE_REMOTE) {
    if (one) lstrcat(StateFlags, L" "); one = true;
    lstrcat(StateFlags, L"REMOTE");
  }
  if (DisplayDevice.StateFlags & DISPLAY_DEVICE_DISCONNECT) {
    if (one) lstrcat(StateFlags, L" "); one = true;
    lstrcat(StateFlags, L"DISCONNECT");
  }
  if (DisplayDevice.StateFlags & DISPLAY_DEVICE_TS_COMPATIBLE) {
    if (one) lstrcat(StateFlags, L" "); one = true;
    lstrcat(StateFlags, L"TS_COMPATIBLE");
  }
  if (DisplayDevice.StateFlags & DISPLAY_DEVICE_UNSAFE_MODES_ON) {
    if (one) lstrcat(StateFlags, L" "); one = true;
    lstrcat(StateFlags, L"UNSAFE_MODES_ON");
  }
  if (DisplayDevice.StateFlags & DISPLAY_DEVICE_MODESPRUNED) {
    if (one) lstrcat(StateFlags, L" "); one = true;
    lstrcat(StateFlags, L"MODESPRUNED");
  }
  if (DisplayDevice.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE) {
    if (one) lstrcat(StateFlags, L" "); one = true;
    lstrcat(StateFlags, L"PRIMARY_DEVICE");
  }
  if (DisplayDevice.StateFlags & DISPLAY_DEVICE_VGA_COMPATIBLE) {
    if (one) lstrcat(StateFlags, L" "); one = true;
    lstrcat(StateFlags, L"VGA_COMPATIBLE");
  }

  static const PCWSTR fmt[2] =
  {
    L"Number: %d\r\n"
    L"Name:   %s\r\n"
    L"String: %s\r\n"
    L"Flags:  %08x [%s]\r\n"
    L"ID:     '%s'\r\n"
    L"Key:    '%s'\r\n\r\n",

    L"    Number: %d\r\n"
    L"    Name:   %s\r\n"
    L"    String: %s\r\n"
    L"    Flags:  %08x [%s]\r\n"
    L"    ID:     '%s'\r\n"
    L"    Key:    '%s'\r\n\r\n"
  };


  p += wsprintf(p, 
                fmt[indent != 0],
                iDevNum,
                DisplayDevice.DeviceName,
                DisplayDevice.DeviceString,
                DisplayDevice.StateFlags,StateFlags,
                DisplayDevice.DeviceID,
                DisplayDevice.DeviceKey);

  return p;
}


extern "C" int mainCRTStartup(void) 
{

  PWSTR pszArg,pszCommandLine = get_command_line();
  BOOL bQuoted;

  DWORD dwFlags = 0;

  while (pszArg = get_next_arg(&pszCommandLine, 0, &bQuoted), *pszArg) 
  {
    if (!bQuoted && *pszArg == L'-') 
    { 
      if (pszArg[1] == L'e') 
      {
        if (pszArg[2] == L'-')
          dwFlags &= ~EDD_GET_DEVICE_INTERFACE_NAME;
        else
          dwFlags |= EDD_GET_DEVICE_INTERFACE_NAME;
      }
    }
  }

  DWORD iDevNum = 0;
  DISPLAY_DEVICE DisplayDevice;
  DisplayDevice.cb = sizeof(DisplayDevice);

  Ptr<WCHAR> buf(16384);
  PWSTR p = buf;
  while (EnumDisplayDevices(0, iDevNum, &DisplayDevice, dwFlags)) {
    p = disp(p, iDevNum, DisplayDevice, false);

    DISPLAY_DEVICE DisplayDevice2;
    DisplayDevice2.cb = sizeof(DisplayDevice2);
    DWORD i = 0;
    while (EnumDisplayDevices(DisplayDevice.DeviceName, i, &DisplayDevice2, dwFlags)) {
      p = disp(p, i, DisplayDevice2, true);
      ++i;
    }

    ++iDevNum;
  }
  //DWORD dwError = GetLastError();

  HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
  display(hStdout, buf, p-buf);

  return 0;
}