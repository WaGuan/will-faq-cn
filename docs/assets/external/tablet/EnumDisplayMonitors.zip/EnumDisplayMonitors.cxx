#include <no_crt.hxx>
#include <ptr.h>

using namespace mph::no_crt;

static BOOL CALLBACK MonitorEnumProc(HMONITOR hMonitor, HDC, LPRECT lpRect, LPARAM lParam) 
{
  PWSTR * pp = reinterpret_cast<PWSTR *>(lParam);

  *pp += wsprintf(*pp, L"lpRect {%d,%d %d,%d}\r\n", lpRect->left, lpRect->top, lpRect->right, lpRect->bottom);

  MONITORINFOEX MonitorInfoEx;
  MonitorInfoEx.cbSize = sizeof(MonitorInfoEx);

  if (GetMonitorInfo(hMonitor, &MonitorInfoEx)) 
  {
    WCHAR szFlags[256];
    PWSTR f = szFlags;

    szFlags[0] = 0;
    if (MonitorInfoEx.dwFlags & MONITORINFOF_PRIMARY) 
    {
      f += wsprintf(f, L"MONITORINFOF_PRIMARY");
    }

    *pp += wsprintf(*pp, 
                  L"  rcMonitor = {%4d,%4d %4d,%4d}\r\n"
                  L"  rcWork    = {%4d,%4d %4d,%4d}\r\n"
                  L"  dwFlags   = 0x%08x [%s]\r\n"
                  L"  szDevice  = %s\r\n\r\n",
                  MonitorInfoEx.rcMonitor.left, 
                  MonitorInfoEx.rcMonitor.top, 
                  MonitorInfoEx.rcMonitor.right, 
                  MonitorInfoEx.rcMonitor.bottom,
                  MonitorInfoEx.rcWork.left, 
                  MonitorInfoEx.rcWork.top, 
                  MonitorInfoEx.rcWork.right, 
                  MonitorInfoEx.rcWork.bottom,
                  MonitorInfoEx.dwFlags, szFlags,
                  MonitorInfoEx.szDevice);
  }
  else 
  {
    *pp += wsprintf(*pp, L"  GetMonitorInfo() failed %d\r\n\r\n", GetLastError());
  }

  return TRUE;
}

extern "C" int mainCRTStartup(void) 
{
  HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);

  mph::no_crt::Ptr<WCHAR> buf(16384);
  PWSTR p = buf;
  if (EnumDisplayMonitors(0, 0, MonitorEnumProc, reinterpret_cast<LPARAM>(&p))) {
    mph::no_crt::display(hStdout, buf, p-buf);
  }
  else 
  {
    mph::no_crt::display_error(hStdout, GetLastError());
  }

  return 0;
}