// Wacom DTU-1031 Sample
// This is a scratch program to illustrate using the DTU-1031 as an 'independant' device.
// Windows is not designed for this type of operation, but this program attempts to
// simulate this type of application design.
// Note that error checking is minimal in order to show the design concepts.
//
// cl /Zi /MTd /I\trunk\include\win\wintab scratch2.cxx

#ifndef UNICODE
#define UNICODE 1
#endif
#ifndef NTDDI_VERSION
#define NTDDI_VERSION NTDDI_WIN7
#endif

#pragma comment(linker,"-DEFAULTLIB:USER32.LIB")
#pragma comment(linker,"-DEFAULTLIB:GDI32.LIB")

#include <windows.h>
#include <objbase.h>

#define PACKETDATA (\
                    PK_CONTEXT           |\
                    PK_STATUS            |\
                    PK_TIME              |\
                    PK_CHANGED           |\
                    PK_SERIAL_NUMBER     |\
                    PK_CURSOR            |\
                    PK_BUTTONS           |\
                    PK_X                 |\
                    PK_Y                 |\
                    PK_NORMAL_PRESSURE   |\
                    PK_ORIENTATION       \
                   )
#define PACKETMODE (0)
#define PACKETEXPKEYS           PKEXT_ABSOLUTE

#include <wintab.h>
#include <pktdef.h>

struct Wintab
{
  HINSTANCE   m_hWintab;

  UINT (API * m_WTInfoW)(UINT, UINT, LPVOID);
  HCTX (API * m_WTOpenW)(HWND, LPLOGCONTEXTW, BOOL);
  BOOL (API * m_WTClose)(HCTX);
  int  (API * m_WTQueueSizeSet)(HCTX, int);
  BOOL (API * m_WTEnable)(HCTX, BOOL);
  BOOL (API * m_WTOverlap)(HCTX, BOOL);
  int  (API * m_WTPacketsGet)(HCTX, int, LPVOID);
  BOOL (API * m_WTExtGet)(HCTX, UINT, LPVOID);
  BOOL (API * m_WTExtSet)(HCTX, UINT, LPVOID);
};

HINSTANCE   g_hInstance;

Wintab      g_wintab;
LOGCONTEXTW g_lc;
HCTX        g_hCtx;

WTPKT       g_expKeys_Mask;

RECT        g_client; // main client window rect, used to map high resolution pen coordinates to pixels.
int         g_state; // 0=up, -1=down, +ve [indexButton+1]


const int g_key_x       = 10;
const int g_key_y       = 10;
const int g_key_x_space = 0;
const int g_key_y_space = 86;
const int g_key_w       = 50;
const int g_key_h       = 50;

int g_keyCount;
int g_keyState[256]; // should really allocate!

HWND g_hWndCursor;// virtual cursor

struct Button
{
  HWND m_hWnd;
  RECT m_rc;
};
Button g_buttons[2];

HWND g_hTextWnd; // simple window for displaying text in.

//=============================================================================

// some helper functions to find the Wacom device.

class DeviceToMonitor
{
  PCWSTR          m_pszDeviceName;
  LPMONITORINFOEX m_pMonitorInfoEx;
  bool            m_found;

  static BOOL CALLBACK MonitorEnumProc(HMONITOR hMonitor, HDC, LPRECT, LPARAM lParam);
  BOOL monitorEnumProc(HMONITOR hMonitor);

public:
  bool deviceToMonitor(PCWSTR pszDeviceName, MONITORINFOEX & MonitorInfoEx);
};

BOOL DeviceToMonitor::monitorEnumProc(HMONITOR hMonitor)
{
  if (GetMonitorInfo(hMonitor, m_pMonitorInfoEx)) 
  {
    m_found = (lstrcmpi(m_pszDeviceName, m_pMonitorInfoEx->szDevice) == 0);
    return !m_found;
  }
  return TRUE;
}

BOOL CALLBACK DeviceToMonitor::MonitorEnumProc(HMONITOR hMonitor, HDC, LPRECT, LPARAM lParam)
{
  return reinterpret_cast<DeviceToMonitor*>(lParam)->monitorEnumProc(hMonitor);
}

bool DeviceToMonitor::deviceToMonitor(PCWSTR pszDeviceName, MONITORINFOEX & MonitorInfoEx)
{
  m_pszDeviceName  = pszDeviceName;
  m_pMonitorInfoEx = &MonitorInfoEx;
  m_found          = false;

  MonitorInfoEx.cbSize = sizeof(MONITORINFOEX);
  EnumDisplayMonitors(nullptr, nullptr, MonitorEnumProc, reinterpret_cast<LPARAM>(this));
  // ignore return, found will stay false if failed

  return m_found;
}



bool findWacomMonitor(MONITORINFOEX & MonitorInfoEx) 
{
  DWORD iDevNum = 0;
  for (;;)
  {
    // enumerates video card desktops
    // eg. \\.\DISPLAY1

    DISPLAY_DEVICE DisplayDevice = { sizeof(DISPLAY_DEVICE) };
    if (EnumDisplayDevices(nullptr, iDevNum, &DisplayDevice, 0))
    { 
      if (DisplayDevice.StateFlags & DISPLAY_DEVICE_ATTACHED_TO_DESKTOP) 
      {
        DWORD iDevNum_2 = 0;
        for (;;)
        {
          // enumerate displays attached to video card
          // eg. \\.\DISPLAY1\Monitor0

          DISPLAY_DEVICE DisplayDevice_2 = { sizeof(DISPLAY_DEVICE) };
          if (EnumDisplayDevices(DisplayDevice.DeviceName, iDevNum_2, &DisplayDevice_2, 0))
          {
            if (DisplayDevice_2.StateFlags & DISPLAY_DEVICE_ATTACHED_TO_DESKTOP)
            {
              static const WCHAR szMonitorString[] = L"Monitor\\WAC"; // Find any Wacom monitor
              //static const WCHAR szMonitorString[] = L"Monitor\\WAC1039"; // explicitly find the first DTU-1031

              static const DWORD dwMonitorString = sizeof(szMonitorString)/sizeof(szMonitorString[0]) - 1;

              if (_wcsnicmp(DisplayDevice_2.DeviceID, szMonitorString, dwMonitorString) == 0) 
              {
                // found something that should be a Wacom monitor
                return DeviceToMonitor().deviceToMonitor(DisplayDevice.DeviceName, MonitorInfoEx);
              }
            }
          }
          else
          {
            break;
          }
          ++iDevNum_2;
        }
      }
    }
    else
    {
      break;
    }

    ++iDevNum;
  }

  return false;
}


bool FindWTExtension(UINT tag, UINT * index)
{
  UINT value;
  for (UINT i = 0; i < EXT_MAX && g_wintab.m_WTInfoW(WTI_EXTENSIONS + i, EXT_TAG, &value); ++i)
  {
    if (value == tag)
    {
      *index = i;
      return true;
    }
  }
  return false;
}

//=============================================================================

template<typename T>
BOOL WTExtGet_helper(HCTX hCtx,
                     UINT wExt,
                     BYTE tabletIndex,
                     BYTE controlIndex,
                     BYTE functionIndex,
                     WORD propertyID, 
                     T *  data)
{
  BYTE * buffer = new BYTE [sizeof(EXTPROPERTY) + sizeof(T)]; // should check for null or exception

  EXTPROPERTY * extProperty = reinterpret_cast<EXTPROPERTY *>(buffer);

  // fill in the data
  extProperty->version       = 0;
  extProperty->tabletIndex   = tabletIndex;
  extProperty->controlIndex  = controlIndex;
  extProperty->functionIndex = functionIndex;
  extProperty->propertyID    = propertyID;
  extProperty->reserved      = 0;
  extProperty->dataSize      = sizeof(T);

  // send the command to Wintab
  BOOL retval = g_wintab.m_WTExtGet(hCtx, wExt, extProperty);
  if (retval)
  {
    *data = *reinterpret_cast<T*>(&extProperty->data[0]);
  }

  delete [] buffer;

  return retval;
}

template<typename T>
BOOL WTExtSet_helper(HCTX hCtx,
                     UINT wExt,
                     BYTE tabletIndex,
                     BYTE controlIndex,
                     BYTE functionIndex,
                     WORD propertyID, 
                     T const & data)
{
  BYTE * buffer = new BYTE [sizeof(EXTPROPERTY) + sizeof(T)]; // should check for null or exception

  EXTPROPERTY * extProperty = reinterpret_cast<EXTPROPERTY *>(buffer);

  // fill in the data
  extProperty->version       = 0;
  extProperty->tabletIndex   = tabletIndex;
  extProperty->controlIndex  = controlIndex;
  extProperty->functionIndex = functionIndex;
  extProperty->propertyID    = propertyID;
  extProperty->reserved      = 0;
  extProperty->dataSize      = sizeof(T);
  *reinterpret_cast<T*>(&extProperty->data[0]) = data;

  // send the command to Wintab
  BOOL retval = g_wintab.m_WTExtSet(hCtx, wExt, extProperty);

  delete [] buffer;

  return retval;
}

//=============================================================================


void wm_destroy(HWND hWnd)
{
  if (g_hCtx)
  {
    g_wintab.m_WTEnable(g_hCtx, FALSE);
    g_wintab.m_WTPacketsGet(g_hCtx, 1024, nullptr);
    g_wintab.m_WTClose(g_hCtx);
    g_hCtx = nullptr;
  }

  if (g_wintab.m_hWintab)
  {
    FreeLibrary(g_wintab.m_hWintab);
    ZeroMemory(&g_wintab, sizeof(g_wintab));
  }

  PostQuitMessage(0);
}



void initKeys()
{
  UINT controlCount = 0;
  if (WTExtGet_helper(g_hCtx, WTX_EXPKEYS2, g_lc.lcDevice, 0, 0, TABLET_PROPERTY_CONTROLCOUNT, &controlCount))
  {
    g_keyCount = controlCount;

    for (UINT controlIndex = 0; controlIndex < controlCount; ++controlIndex)
    {
      g_keyState[controlIndex] = -2;

      UINT functionCount = 0;
      if (WTExtGet_helper(g_hCtx, WTX_EXPKEYS2, g_lc.lcDevice, controlIndex, 0, TABLET_PROPERTY_FUNCCOUNT, &functionCount))
      {
        for (UINT functionIndex = 0; functionIndex < functionCount; ++functionIndex)
        {
          BOOL available = FALSE;
          if (WTExtGet_helper(g_hCtx, WTX_EXPKEYS2, g_lc.lcDevice, controlIndex, functionIndex, TABLET_PROPERTY_AVAILABLE, &available))
          {
            if (WTExtSet_helper(g_hCtx, WTX_EXPKEYS2, g_lc.lcDevice, controlIndex, functionIndex, TABLET_PROPERTY_OVERRIDE, BOOL(TRUE) ))
            {
              g_keyState[controlIndex] = 0;
            }
            else
            {
              g_keyState[controlIndex] = -1;
            }
          }
        }
      }
    }
  }
}


LRESULT wm_create(HWND hWnd)
{
  LRESULT lResult = -1;
  
  g_wintab.m_hWintab = LoadLibrary(L"WINTAB32.DLL");
  if (g_wintab.m_hWintab)
  {
    g_wintab.m_WTInfoW        = reinterpret_cast<UINT (API *)(UINT, UINT, LPVOID)       >(GetProcAddress(g_wintab.m_hWintab, "WTInfoW"));
    g_wintab.m_WTOpenW        = reinterpret_cast<HCTX (API *)(HWND, LPLOGCONTEXTW, BOOL)>(GetProcAddress(g_wintab.m_hWintab, "WTOpenW"));
    g_wintab.m_WTClose        = reinterpret_cast<BOOL (API *)(HCTX)                     >(GetProcAddress(g_wintab.m_hWintab, "WTClose"));
    g_wintab.m_WTQueueSizeSet = reinterpret_cast<int  (API *)(HCTX, int)                >(GetProcAddress(g_wintab.m_hWintab, "WTQueueSizeSet"));
    g_wintab.m_WTEnable       = reinterpret_cast<BOOL (API *)(HCTX, BOOL)               >(GetProcAddress(g_wintab.m_hWintab, "WTEnable"));
    g_wintab.m_WTOverlap      = reinterpret_cast<BOOL (API *)(HCTX, BOOL)               >(GetProcAddress(g_wintab.m_hWintab, "WTOverlap"));
    g_wintab.m_WTPacketsGet   = reinterpret_cast<int  (API *)(HCTX, int, LPVOID)        >(GetProcAddress(g_wintab.m_hWintab, "WTPacketsGet"));
    g_wintab.m_WTExtGet       = reinterpret_cast<BOOL (API *)(HCTX, UINT, LPVOID)       >(GetProcAddress(g_wintab.m_hWintab, "WTExtGet"));
    g_wintab.m_WTExtSet       = reinterpret_cast<BOOL (API *)(HCTX, UINT, LPVOID)       >(GetProcAddress(g_wintab.m_hWintab, "WTExtSet"));
    if (g_wintab.m_WTInfoW
        && g_wintab.m_WTOpenW
        && g_wintab.m_WTClose
        && g_wintab.m_WTQueueSizeSet
        && g_wintab.m_WTEnable
        && g_wintab.m_WTOverlap
        && g_wintab.m_WTPacketsGet
        && g_wintab.m_WTExtGet
        && g_wintab.m_WTExtSet
        )
    {
      if (g_wintab.m_WTInfoW(0,0,0) != 0)
      {
        UINT nDevices = 0;
        g_wintab.m_WTInfoW(WTI_INTERFACE, IFC_NDEVICES, &nDevices);
        if (nDevices == 1) // TODO: ~~~ currently cannot determine device from monitor so only support one device.
        {
          UINT iDevice = 0; // TODO: ~~~ device index to use, currently no way to determine device from monitor.

          AXIS xAxis;
          AXIS yAxis;
          g_wintab.m_WTInfoW(WTI_DEVICES + iDevice, DVC_X, &xAxis);
          g_wintab.m_WTInfoW(WTI_DEVICES + iDevice, DVC_Y, &yAxis);

          UINT extExpKeys2 = 0;
          if (FindWTExtension(WTX_EXPKEYS2, &extExpKeys2))
          {
            g_wintab.m_WTInfoW(WTI_EXTENSIONS+extExpKeys2, EXT_MASK, &g_expKeys_Mask);
          }

          ZeroMemory(&g_lc, sizeof(g_lc));
          lstrcpyW(g_lc.lcName, L"mph scratch");
          g_lc.lcOptions   = CXO_MESSAGES;
          g_lc.lcMsgBase   = WT_DEFBASE;
          g_lc.lcDevice    = iDevice;
          g_lc.lcPktRate   = 200;                         // ignored
          g_lc.lcPktData   = PACKETDATA | g_expKeys_Mask;
          g_lc.lcPktMode   = PACKETMODE;
          g_lc.lcMoveMask  = 0xffffffff;
          g_lc.lcBtnDnMask = 0xffffffff;
          g_lc.lcBtnUpMask = 0xffffffff;
          g_lc.lcOutOrgX   = g_lc.lcInOrgX = xAxis.axMin;
          g_lc.lcOutOrgY   = g_lc.lcInOrgY = yAxis.axMin;
          g_lc.lcOutExtX   = g_lc.lcInExtX = xAxis.axMax - xAxis.axMin;
          g_lc.lcOutExtY   = g_lc.lcInExtY = yAxis.axMax - yAxis.axMin;

          // TODO: ~~~ temporary hack to fix stylus-to-pixel mapping
          {
            PWSTR pszCommandLine = GetCommandLine();
            if (pszCommandLine && wcsstr(pszCommandLine, L"/hack") != nullptr)
            {
              LOGCONTEXTW lc;
              g_wintab.m_WTInfoW(WTI_DEFCONTEXT, 0, &lc);

              g_lc.lcDevice   = lc.lcDevice;
              g_lc.lcInOrgX   = lc.lcInOrgX;
              g_lc.lcInOrgY   = lc.lcInOrgY;
              g_lc.lcInExtX   = lc.lcInExtX;
              g_lc.lcInExtY   = lc.lcInExtY;
              g_lc.lcOutOrgX  = lc.lcOutOrgX;
              g_lc.lcOutOrgY  = lc.lcOutOrgY;
              g_lc.lcOutExtX  = lc.lcOutExtX;
              g_lc.lcOutExtY  = lc.lcOutExtY;
            }
          }

          g_hCtx = g_wintab.m_WTOpenW(hWnd, &g_lc, FALSE);
          
          if (g_hCtx)
          {
            if (extExpKeys2)
              initKeys();

            if (g_wintab.m_WTQueueSizeSet(g_hCtx, 500))
            {
              GetClientRect(hWnd, &g_client);

              g_buttons[0].m_rc.left   = 100;
              g_buttons[0].m_rc.top    = 10;
              g_buttons[0].m_rc.right  = g_buttons[0].m_rc.left + 100;
              g_buttons[0].m_rc.bottom = g_buttons[0].m_rc.top  + 30;

              g_buttons[0].m_hWnd = CreateWindowEx(0, L"BUTTON", L"Clear!", WS_CHILD|WS_VISIBLE, g_buttons[0].m_rc.left, g_buttons[0].m_rc.top, g_buttons[0].m_rc.right-g_buttons[0].m_rc.left, g_buttons[0].m_rc.bottom-g_buttons[0].m_rc.top, hWnd, reinterpret_cast<HMENU>(8001), g_hInstance, nullptr);

              g_buttons[1].m_rc.left   = 300;
              g_buttons[1].m_rc.top    = 10;
              g_buttons[1].m_rc.right  = g_buttons[1].m_rc.left + 100;
              g_buttons[1].m_rc.bottom = g_buttons[1].m_rc.top  + 30;

              g_buttons[1].m_hWnd = CreateWindowEx(0, L"BUTTON", L"Close",     WS_CHILD|WS_VISIBLE, g_buttons[1].m_rc.left, g_buttons[1].m_rc.top, g_buttons[1].m_rc.right-g_buttons[1].m_rc.left, g_buttons[1].m_rc.bottom-g_buttons[1].m_rc.top, hWnd, reinterpret_cast<HMENU>(8099), g_hInstance, nullptr);

              g_hTextWnd = CreateWindowEx(0, L"STATIC", L"",     WS_CHILD|WS_VISIBLE|SS_NOPREFIX|SS_SIMPLE, 16, g_client.bottom-100, 280, 20, hWnd, reinterpret_cast<HMENU>(8098), g_hInstance, nullptr);
              SendMessage(g_hTextWnd, WM_SETFONT, reinterpret_cast<WPARAM>(GetStockObject(ANSI_FIXED_FONT)), FALSE);

              // create a virtual cursor
              // note cannot be a WS_CHILD due to WS_EX_LAYERED.
              g_hWndCursor = CreateWindowEx(WS_EX_LAYERED|WS_EX_TRANSPARENT|WS_EX_NOACTIVATE|WS_EX_TOPMOST, L"Cursor", nullptr, WS_POPUP, 0,0,0,0, hWnd, nullptr, g_hInstance, nullptr);

              g_wintab.m_WTEnable(g_hCtx, TRUE);

              lResult = 0;

            }
          }
        }
      }
    }
  }

  return lResult;
}



void packet2client(PACKET & pkt, POINT & pt)
{
  pt.x = MulDiv(g_client.right-g_client.left, pkt.pkX, g_lc.lcOutExtX);
  pt.y = g_client.bottom - MulDiv(g_client.bottom-g_client.top, pkt.pkY, g_lc.lcOutExtY);
}

void draw_cross(HWND hWnd, POINT & pt, BOOL isDown)
{
  HDC hdc = GetDC(hWnd);

  HGDIOBJ ho = SelectObject(hdc, GetStockObject(DC_PEN));
  SetDCPenColor(hdc, isDown ? RGB(0,0,127) : RGB(128,128,191) );

  MoveToEx(hdc, pt.x - 2, pt.y, nullptr);
  LineTo(hdc, pt.x + 3, pt.y);
  MoveToEx(hdc, pt.x, pt.y-2, nullptr);
  LineTo(hdc, pt.x, pt.y+3);

  SelectObject(hdc, ho);

  ReleaseDC(hWnd, hdc);
}

void wt_packetext1(HWND hWnd, PACKETEXT & pkt)
{
  int i = pkt.pkExpKeys.nControl;

  g_keyState[i] = (pkt.pkExpKeys.nState != 0);
  
  int x = g_key_x + i*g_key_x_space;
  int y = g_key_y + i*g_key_y_space;

  RECT rc;
  rc.left   = x;
  rc.top    = y;
  rc.right  = x + g_key_w;
  rc.bottom = y + g_key_h;
  
  InvalidateRect(hWnd, &rc, FALSE);
}

void wt_packet1(HWND hWnd, PACKET & pkt)
{
  // A real app would have more complex processing.
  // This tracks the pen and uses it to simulate button presses.
  
  POINT pt;
  packet2client(pkt, pt);

  {
    WCHAR szBuffer[100];
    wsprintf(szBuffer, L"(%5d,%5d) \x2192 (%5d,%5d)", pkt.pkX, pkt.pkY, pt.x, pt.y);
    SetWindowText(g_hTextWnd, szBuffer);
  }

  bool isDown = (pkt.pkButtons & 1) != 0;

  int button = 0;
  for (int i = 0; i < _countof(g_buttons); ++i)
  {
    if (PtInRect(&g_buttons[i].m_rc, pt))
    {
      button = i+1;
      break;
    }
  }

  if (isDown)
  {
    if (g_state == 0) // up
    {
      // transition to down
      
      if (button)
      {
        // transition to down in a button, set it to pressed
        g_state = button;

        SendMessage(g_buttons[button-1].m_hWnd, BM_SETSTATE, TRUE, 0);
      }
      else
      {
        // transition to down elsewhere, just draw
        g_state = -1;

        draw_cross(hWnd, pt, TRUE);
      }
    }
    else if (g_state == -1) // pendown
    {
      draw_cross(hWnd, pt, TRUE);
    }
    else // button
    {
      // get state of button we are tracking
      bool pushed = (SendMessage(g_buttons[g_state-1].m_hWnd, BM_GETSTATE, 0,0) & BST_PUSHED) != 0;

      if (button != g_state && pushed)
      {
        SendMessage(g_buttons[g_state-1].m_hWnd, BM_SETSTATE, FALSE, 0);
      }
      else if (button == g_state && !pushed)
      {
        SendMessage(g_buttons[g_state-1].m_hWnd, BM_SETSTATE, TRUE, 0);
      }
    }
  }
  else
  {
    if (g_state == -1)
    {
      // transition to up
      g_state = 0;

      //draw_cross(hWnd, pt, FALSE);
    }
    else if (g_state > 0)
    {
      if (button)
      {
        HWND hButton = g_buttons[button-1].m_hWnd;

        // Simulate the button being pressed.
        // you cannot send the control a BM_CLICK message as this may fail when the control is not active.
        // see: http://msdn.microsoft.com/en-gb/library/windows/desktop/bb775985(v=vs.85).aspx

        // warning: If you use SendMessage here, then beware that there may still be WT_PACKETS in the message queue.
        //          This can lead to crashes if you close the context within within this call stack!
        PostMessage(GetParent(hButton), WM_COMMAND, MAKEWPARAM(static_cast<WORD>(GetDlgCtrlID(hButton)), BN_CLICKED), reinterpret_cast<LPARAM>(hButton));
      }

      SendMessage(g_buttons[g_state-1].m_hWnd, BM_SETSTATE, FALSE, 0);

      g_state = 0;
    }
    else // (g_state == 0)
    {
      // do nothing
      //draw_cross(hWnd, pt, FALSE);
    }
  }

  SendMessage(g_hWndCursor, WM_USER+0, pt.x, pt.y); // update the virtual cursor
}

void wt_proximity(LPARAM lParam)
{
  // Hide the virtual cursor if the stylus goes out of proximity.
  if (LOWORD(lParam) == 0)
  {
    ShowWindow(g_hWndCursor, SW_HIDE);
  }
}

void wt_ctxoverlap(HCTX hCtx, UINT status)
{
  // Dangerous!
  // override the default behaviour of Wacom's Wintab automatically changing the overlap order.
  // If another application attempts to do the same then both applications will deadlock.
  if (hCtx == g_hCtx && (status & CXS_ONTOP) == 0)
  {
    // Keep us topmost!
    g_wintab.m_WTOverlap(g_hCtx, TRUE);
  }
}


void wt_packet(HWND hWnd)
{  
  // use wt_packet to track the stylus.
  for (;;)
  {
    PACKET pktbuf[100] = { 0 };
    int n = g_wintab.m_WTPacketsGet(g_hCtx, 100, pktbuf);
    if (n) 
    {
      for (int i = 0; i < n; ++i) 
      {
        wt_packet1(hWnd, pktbuf[i]);
      }
    }
    else 
    {
      break;
    }
  }
}


void wt_packetext(HWND hWnd, HCTX hCtx)
{
  // use wt_packetext to track the Express Keys. Note the use of lParam as the Wintab context.
  for (;;)
  {
    PACKETEXT pktbuf[100] = { 0 };
    int n = g_wintab.m_WTPacketsGet(hCtx, 100, pktbuf);
    if (n) 
    {
      for (int i = 0; i < n; ++i) 
      {
        wt_packetext1(hWnd, pktbuf[i]);
      }
    }
    else 
    {
      break;
    }
  }
}


LRESULT wm_command(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
  LRESULT lResult = 0;

  switch (LOWORD(wParam))
  {
    case 8001:
      //MessageBeep(-1);
      InvalidateRect(hWnd, nullptr, TRUE);
      break;

    case 8099:
      SendMessage(hWnd, WM_CLOSE, 0, 0);
      break;

    default:
      lResult = DefWindowProc(hWnd, WM_COMMAND, wParam, lParam);
  }

  return lResult;
}


void paint(HWND hWnd, PAINTSTRUCT & ps)
{
  HGDIOBJ ho[3];
  ho[0] = GetStockObject(DKGRAY_BRUSH);
  ho[1] = GetStockObject(GRAY_BRUSH);
  ho[2] = GetStockObject(LTGRAY_BRUSH);
    
  for (UINT i = 0; i < g_keyCount; ++i)
  {
    auto state = g_keyState[i];

    int x = g_key_x + i*g_key_x_space;
    int y = g_key_y + i*g_key_y_space;
  
    RECT rc;
    rc.left   = x;
    rc.top    = y;
    rc.right  = x + g_key_w;
    rc.bottom = y + g_key_h;
    
    int s;
    if (state < 0)
      s = 0;
    else if (state == 0)
      s = 1;
    else
      s = 2;

    HGDIOBJ hoo = SelectObject(ps.hdc, ho[s]);

    Ellipse(ps.hdc, rc.left, rc.top, rc.right, rc.bottom);

    SelectObject(ps.hdc, hoo);
  }
}


//=============================================================================
// virtual cursor handling

static void wm_user_updateCursor(HWND hWnd, int x, int y)
{
  // move and display the cursor to the x,y coordinates, which are specified in client coordinates of the parent window.

  HWND hParentWnd = GetParent(hWnd);

  HCURSOR hCursor = reinterpret_cast<HCURSOR>(GetWindowLongPtr(hWnd, GWLP_USERDATA));

  int w = GetSystemMetrics(SM_CXCURSOR);
  int h = GetSystemMetrics(SM_CYCURSOR);

  RECT rc = { 0, 0, w, h };

  // Alternatively, use BeginBufferedPaint()...
  // http://blogs.msdn.com/b/oldnewthing/archive/2011/05/20/10166505.aspx

  HDC     hDC;
  HBITMAP hBitmap;
  {
    HDC hDCWnd = GetDC(hWnd);
    hDC     = CreateCompatibleDC(hDCWnd);
    hBitmap = CreateCompatibleBitmap(hDCWnd, w, h);
    ReleaseDC(hWnd, hDCWnd);
  }
  HGDIOBJ hbit = SelectObject(hDC, hBitmap);

  FillRect(hDC, &rc, (HBRUSH)GetStockObject(BLACK_BRUSH));

  DrawIconEx(hDC, 0, 0, (HICON)hCursor, 0, 0, 0, nullptr, DI_NORMAL | DI_COMPAT);

  ICONINFO iconInfo = { 0 };
  GetIconInfo(hCursor, &iconInfo);

  SIZE  szDst = { w, h };
  POINT ptDst = { x - iconInfo.xHotspot, y - iconInfo.yHotspot };
  MapWindowPoints(hParentWnd, nullptr, &ptDst, 1);

  if (iconInfo.hbmMask)  DeleteObject(iconInfo.hbmMask);
  if (iconInfo.hbmColor) DeleteObject(iconInfo.hbmColor);

  BLENDFUNCTION blend = { 0 };
  blend.BlendOp             = AC_SRC_OVER;
  blend.SourceConstantAlpha = 0xff;
  blend.AlphaFormat         = AC_SRC_ALPHA;

  POINT ptSrc = { 0, 0 };

  ShowWindow(hWnd, SW_SHOWNOACTIVATE);
  UpdateLayeredWindow(hWnd, nullptr, &ptDst, &szDst, hDC, &ptSrc, 0, &blend, ULW_ALPHA);

  SelectObject(hDC, hbit);
  DeleteObject(hBitmap);
  DeleteDC(hDC);
}

static LRESULT CALLBACK CursorWndProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam) // Virtual Cursor
{
  LRESULT lResult = 0;
  switch (uMessage)
  {
    case WM_USER+0: // update position
      wm_user_updateCursor(hWnd, wParam, lParam);
      break;

    /*
    case WM_USER+1: // set new hcursor
      {
        HCURSOR hCursor = reinterpret_cast<HCURSOR>(GetWindowLongPtr(hWnd, GWLP_USERDATA));
        DestroyCursor(hCursor);
        SetWindowLongPtr(hWnd, GWLP_USERDATA, lParam);
      }
      break;

    case WM_USER+2: // get current hcursor
      {
        lResult = GetWindowLongPtr(hWnd, GWLP_USERDATA);
      }
      break;
    */

    case WM_DESTROY:
      {
        HCURSOR hCursor = reinterpret_cast<HCURSOR>(GetWindowLongPtr(hWnd, GWLP_USERDATA));
        DestroyCursor(hCursor);
      }
      break;

    case WM_CREATE:
      {
        HCURSOR hCursor = LoadCursor(nullptr, IDC_ARROW); // by default, just use arrow. (use WM_USER+1 to change)
        SetWindowLongPtr(hWnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(hCursor));
      }
      break;

    default:
      lResult = DefWindowProc(hWnd, uMessage, wParam, lParam);
  }
  return lResult;
}

//=============================================================================

static LRESULT CALLBACK WndProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
  LRESULT lResult = 0;

  switch (uMessage)
  {
    case WT_CTXOVERLAP:
      wt_ctxoverlap(reinterpret_cast<HCTX>(wParam), static_cast<UINT>(lParam));
      break;

    case WT_PROXIMITY:
      wt_proximity(lParam);
      break;

    case WT_PACKET:
      wt_packet(hWnd);
      break;

    case WT_PACKETEXT:
      wt_packetext(hWnd, reinterpret_cast<HCTX>(lParam));
      break;

    case WM_COMMAND:
      lResult = wm_command(hWnd, wParam, lParam);
      break;

    case WM_DESTROY:
      wm_destroy(hWnd);
      break;

    case WM_PAINT:
      {
        PAINTSTRUCT ps;
        BeginPaint(hWnd, &ps);
        paint(hWnd, ps);
        EndPaint(hWnd, &ps);
      }
      break;

    case WM_CREATE:
      lResult = wm_create(hWnd);
      break;

    default:
      lResult = DefWindowProc(hWnd, uMessage, wParam, lParam);
  }
  return lResult;
}


int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int)
{
  g_hInstance = hInstance;

  {
    // This window class is to handle a virtual cursor
    WNDCLASSEX wc = { sizeof(WNDCLASSEX) };
    wc.lpfnWndProc   = CursorWndProc;
    wc.hInstance     = hInstance;
    wc.lpszClassName = L"Cursor";
    RegisterClassEx(&wc);
  }

  WNDCLASSEX wc = { sizeof(WNDCLASSEX) };
  wc.style         = 0;
  wc.lpfnWndProc   = WndProc;
  wc.hInstance     = hInstance;
  wc.hCursor       = LoadCursor(nullptr, IDC_NO);
  wc.hbrBackground = CreateSolidBrush(RGB(255,255,200));
  wc.lpszClassName = L"Scratch Class";

  ATOM atom = RegisterClassEx(&wc);
  if (atom)
  {
    //HRESULT hr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    //if (SUCCEEDED(hr))
    {
      int left, top, width, height;

      MONITORINFOEX monitorInfoEx;
      if (findWacomMonitor(monitorInfoEx))
      {
        left = monitorInfoEx.rcWork.left;
        top  = monitorInfoEx.rcWork.top;
        width = monitorInfoEx.rcWork.right - monitorInfoEx.rcWork.left;
        height = monitorInfoEx.rcWork.bottom - monitorInfoEx.rcWork.top;
      }
      else
      {
        left = top = width = height = CW_USEDEFAULT;
      }

      HWND hWnd = CreateWindowEx(WS_EX_TOPMOST|WS_EX_NOACTIVATE, MAKEINTRESOURCE(atom), L"scratch window", WS_CLIPCHILDREN|WS_POPUP|WS_VISIBLE, left, top, width, height, nullptr, nullptr, hInstance, nullptr);
      if (hWnd)
      {
        MSG msg;
        while (GetMessage(&msg, nullptr, 0, 0) > 0)
        {
          TranslateMessage(&msg);
          DispatchMessage(&msg);
        }
      }

      //CoUninitialize();
    }
  }

  return 0;
}
